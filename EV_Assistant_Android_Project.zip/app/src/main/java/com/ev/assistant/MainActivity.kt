package com.ev.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var recognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private lateinit var log: TextView
    private lateinit var status: TextView
    private lateinit var talk: Button
    private lateinit var scroll: ScrollView
    private lateinit var core: ImageView

    private val requestAudio = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        log = findViewById(R.id.log)
        status = findViewById(R.id.status)
        talk = findViewById(R.id.talk)
        scroll = findViewById(R.id.scroll)
        core = findViewById(R.id.core)

        tts = TextToSpeech(this, this)

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "● التعرف على الصوت غير متاح"
            talk.isEnabled = false
            return
        }

        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(listener)

        talk.setOnClickListener {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            } else {
                startListening()
            }
        }
    }

    private fun startListening() {
        status.text = "● أستمع..."
        talk.text = "⏹️ أستمع..."
        core.animate().scaleX(1.06f).scaleY(1.06f).setDuration(180).start()

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-EG")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer.startListening(intent)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            status.text = "● معالجة..."
        }
        override fun onError(error: Int) {
            resetUi()
            val message = when (error) {
                SpeechRecognizer.ERROR_AUDIO -> "تعذر الوصول إلى الميكروفون."
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "تحقق من اتصال الإنترنت."
                SpeechRecognizer.ERROR_NO_MATCH -> "لم أفهم الكلام. حاول مرة أخرى."
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "لم أسمع كلامًا."
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "خدمة الصوت مشغولة. حاول بعد لحظة."
                else -> "حدث خطأ في التعرف على الصوت. الكود: $error"
            }
            addEv(message)
            speak(message)
        }
        override fun onResults(results: Bundle?) {
            resetUi()
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull() ?: return
            addUser(text)
            handleCommand(text)
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleCommand(raw: String) {
        val t = raw.lowercase(Locale("ar", "EG"))

        when {
            t.contains("بطارية") -> {
                val percent = getBatteryPercent()
                reply("حالة البطارية $percent بالمئة.")
            }
            t.contains("الوقت") || t.contains("الساعة") -> {
                val time = java.text.SimpleDateFormat("h:mm a", Locale("ar", "EG"))
                    .format(java.util.Date())
                reply("الوقت الآن $time.")
            }
            t.contains("يوتيوب") -> {
                reply("حاضر. سأفتح يوتيوب.")
                openUrl("https://www.youtube.com/")
            }
            t.contains("جوجل") -> {
                reply("حاضر. سأفتح جوجل.")
                openUrl("https://www.google.com/")
            }
            t.contains("ابحث") || t.contains("بحث") -> {
                val q = raw.replace(Regex("ابحث|بحث|عن"), "").trim()
                if (q.isEmpty()) reply("قل لي ماذا تريد أن أبحث عنه.")
                else {
                    reply("سأبحث عن $q.")
                    openUrl("https://www.google.com/search?q=" + Uri.encode(q))
                }
            }
            t.contains("اسمك") || t.contains("أنت مين") || t.contains("انت مين") -> {
                reply("أنا E.V. مساعدك الشخصي، وهذه أول نسخة كتطبيق أندرويد.")
            }
            t.contains("مرحبا") || t.contains("أهلا") || t.contains("اهلا") -> {
                reply("مرحبًا. أنظمة E.V. تعمل.")
            }
            else -> reply("سمعتك: $raw. ما زلت في النسخة الأولية، ويمكن إضافة أوامر أكثر.")
        }
    }

    private fun reply(text: String) {
        addEv(text)
        speak(text)
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "EV_REPLY")
        }
    }

    private fun addUser(text: String) {
        log.append("\n\nأنت: $text")
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addEv(text: String) {
        log.append("\n\nE.V.: $text")
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun resetUi() {
        status.text = "● جاهز"
        talk.text = "🎙️ تحدث"
        core.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
    }

    private fun getBatteryPercent(): Int {
        val bm = getSystemService(BATTERY_SERVICE) as android.os.BatteryManager
        return bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    private fun openUrl(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("ar", "EG")
        }
    }

    override fun onDestroy() {
        if (::recognizer.isInitialized) recognizer.destroy()
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
